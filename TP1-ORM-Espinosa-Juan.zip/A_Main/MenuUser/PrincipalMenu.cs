using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace A_Main.MenuUser;

public class PrincipalMenu
{
    public static void MainMenu(){
        Console.WriteLine("**************************************************");
        Console.WriteLine("**************** MENU PRINCIPAL ******************");
        Console.WriteLine("**************************************************");
        Console.WriteLine("\n");
        Console.WriteLine("Elija una opcion");
        Console.WriteLine("\n");
        Console.WriteLine("1) Mostrar listado de productos");
        Console.WriteLine("2) Comprar productos");
        Console.WriteLine("3) Salir");
    }
}